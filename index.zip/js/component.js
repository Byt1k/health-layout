// const SelectCountry = () => {
  
// }

// const root = ReactDOM.createRoot(
//   document.getElementById('selectCountry')
// );

// root.render(<SelectCountry/>)